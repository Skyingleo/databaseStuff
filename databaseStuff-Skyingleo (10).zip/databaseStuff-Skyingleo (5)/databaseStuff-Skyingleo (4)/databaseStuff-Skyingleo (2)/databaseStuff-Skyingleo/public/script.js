//setInterval(run, 2000);
const socket = io();
const Title = document.getElementById("Title");

    let Author = document.getElementById("Author");
    //const cTree = document.getElementsByClassName("body-bg");
    let bdisplay = document.getElementById("bdisplay");

    let barCode = document.getElementById("barCode");
    let title = document.getElementById("title");
    let author = document.getElementById("author");
    let callN = document.getElementById("callN");
    let status = document.getElementById("status");
    let llocation = document.getElementById("llocation");
    let sublocation = document.getElementById("sublocation");
    let glimit = document.getElementById("glimit");
    let date = document.getElementById("date");
    let series = document.getElementById("series");

    let 

    let udisplay = document.getElementById("udisplay");

    let firstN = document.getElementById("firstN");
    let lastN = document.getElementById("lastN");
    let grade = document.getElementById("grade");
    let advisor = document.getElementById("advisor");
    let email1 = document.getElementById("email1");
    let email2 = document.getElementById("email2");
    let veracross = document.getElementById("veracross");
    let uclass = document.getElementById("uclass");
    let Uname = document.getElementById("Uname");
    let Pword = document.getElementById("Pword");


    let searchBInput = document.getElementById("searchBInput");
    let bookR = document.getElementById("bookR");

    socket.on("connect", (data) => {
        console.log(data); // x8WIv7-mJelg7on_ALbx
    });
    console.log($('#bEnter'));

    $ ("#bEnter").click(function(){

        console.log($('#llocation').val());
        socket.emit('bSent'
        	, $('#title').val()
        	, $('#author').val()
        	, $('#callN').val()
        	, $('#status').val()
        	, $('#llocation').val()
        	, $('#sublocation').val()
        	, $('#glimit').val()
        	, $('#catagoryid').val()
        	, $('#barCode').val()
        	, $('#date').val()
        	, $('#series').val());
    })

    $ ("#uEnter").click(function(){
        
        socket.emit('uSent'
        	, $('#firstN').val()
        	, $('#lastN').val()
        	, $('#grade').val()
        	, $('#advisor').val()
        	, $('#email1').val()
        	, $('#email2').val()
        	, $('#veracross').val()
        	, $('#uclass').val()
        	, $('#Pword').val()
        	, $('#Uname').val());
    })

    $ ("#sbBEnter").click(function(){
    	console.log("message sent!");
    	socket.emit('sbBSent'
    		, $('#searchBInput').val());

    })

    $ ("#sbTEnter").click(function(){
    	console.log("message sent!");
    	socket.emit('sbTSent'
    		, $('#searchBInput').val());

    })

    $ ("#sbAEnter").click(function(){
    	console.log("message sent!");
    	socket.emit('sbASent'
    		, $('#searchBInput').val());

    })


    let rCategory;
    let rSeries;
    let rLoc;
    let rSubloc;
    let rCallN;
    let rStatus;
    let rDescrip;
    let rComment;

    socket.on('Nbook', function (data){
    	$('#bdisplay').append("<li>"+data+'</li>');
    });

    socket.on('Nuser', function (data){
    	$('#udisplay').append("<li>"+data+'</li>');
    });

    socket.on('Sresult', function (data){
    	$('#bookR').empty();
    	rCategory = data[i].catagoryid;
    	connection.query()

    	for (let i = 0; i < data.length; i++){
    		$('#bookR').append("<li>"+"Book id : "+data[i].id+ " " +'</li>');
    		$('#bookR').append("<li>"+"Title : "+data[i].title +" "+'</li>');
    		$('#bookR').append("<li>"+"Author : "+data[i].author+" "+'</li>');
    		$('#bookR').append("<li>"+"Which Catagory : "+data[i].catagoryid+" "+'</li>');
    		$('#bookR').append("<li>"+"Which Series : "+data[i].series+" "+'</li>');
    		$('#bookR').append("<li>"+"Which Campus : "+data[i].location+" "+'</li>');
    		$('#bookR').append("<li>"+"Where Exactly : "+data[i].sublocation+" "+'</li>');
    		$('#bookR').append("<li>"+"Grade Limit : "+data[i].glimit+" "+'</li>');
    		$('#bookR').append("<li>"+"Date Lended : "+data[i].idate+" "+'</li>');
    		$('#bookR').append("<li>"+"Due Date : "+data[i].ddate+" "+'</li>');
    		$('#bookR').append("<li>"+"Date Stor "+data[i].date+" "+'</li>');
    		$('#bookR').append("<li>"+"Barcode : "+data[i].barCode+" "+'</li>');
    		$('#bookR').append("<li>"+"Call Number :  "+data[i].callN+" "+'</li>');
    		$('#bookR').append("<li>"+"Ownership :  "+data[i].status+" "+'</li>');
    		$('#bookR').append("<li>"+"Description : "+data[i].description+" "+'</li>');
    		$('#bookR').append("<li>"+"Comment : "+data[i].comment+" "+'</li>');
    		$('#bookR').append("<li>"+"User Name : "+data[i].userN+" "+'</li>');
    	}
    });
    // socket.on('count', function (data) {
    //     $('.user-count').html(data);
    // });

    // socket.on('textline', function (data) {
    //     console.log(data);
    //     $('ul').append("<li>"+data+'</li>');
    // });

    // socket.on('bIDr', function (bIDv) {
    //     console.log(bIDv);
    //     $('').append("<li>"+data+'</li>');
    // });

    // socket.on('texthistory', function (data) {
    //     console.log(data);
    //     for (let i = 0; i < data.length; i++){
    //         $('ul').append("<li>"+data[i]+'</li>');
    //     }
    // });
    //<script.src = "/socket.io/socket.io.js">

// socket.on('count', function (data) {
//   $('.user-count').html(data);
// });

// socket.on('textline', function (data) {
// 	console.log(data);
//   	$('ul').append("<li>"+data+'</li>');
// });

// socket.on('bIDr', function (bIDv) {
// 	console.log(bIDv);
//   	$('').append("<li>"+data+'</li>');
// });

// socket.on('texthistory', function (data) {
// 	console.log(data);
// 	for (let i = 0; i < data.length; i++){
// 	  	$('ul').append("<li>"+data[i]+'</li>');
// 	}
// });
//<script.src = "/socket.io/socket.io.js"></script>
