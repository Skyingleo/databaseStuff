
-- CREATE TABLE userClass (
--     level INT AUTO_INCREMENT NOT NULL,
--     bedit INT NOT NULL,
--     comment INT NOT NULL,
--     cedit INT NOT NULL,
--     PRIMARY KEY(level)
--     );


-- CREATE TABLE user (
--     id INT AUTO_INCREMENT NOT NULL,
--     firstN VARCHAR(255) NOT NULL,
--     lastN VARCHAR(255) NOT NULL,
--     grade INT,
--     advisor TEXT,
--     email1 TEXT,
--     email2 TEXT,
--     veracross INT NOT NULL,
--     class INT NOT NULL,
    
--     PRIMARY KEY(id),
--     FOREIGN KEY (class)
--         REFERENCES userClass (level)
--     );


-- CREATE TABLE book (
--     id INT AUTO_INCREMENT NOT NULL,
--     title VARCHAR(255) NOT NULL,
--     author VARCHAR(255) NOT NULL,
--     callN VARCHAR(100) NOT NULL,
--     status INT,
--     location TEXT,
--     sublocation TEXT,
--     glimit INT,
--     idate DATE,
--     ddate DATE,
    
--     PRIMARY KEY(id),
--     FOREIGN KEY (status)
--         REFERENCES user (id)
--     );