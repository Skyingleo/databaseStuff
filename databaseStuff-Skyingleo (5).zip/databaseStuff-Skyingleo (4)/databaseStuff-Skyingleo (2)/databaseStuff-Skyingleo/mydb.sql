CREATE TABLE IF NOT EXISTS book (
    id INTEGER PRIMARY KEY NOT NULL UNIQUE,
    title TEXT NOT NULL,
    author TEXT NOT NULL,
    callN TEXT NOT NULL,
    status INTEGER,
    location TEXT,
    sublocation TEXT,
    glimit INTEGER,
    FOREIGN KEY (status)
        REFERENCES user (id)
    );

CREATE TABLE IF NOT EXISTS user (
    id INTEGER PRIMARY KEY NOT NULL UNIQUE,
    firstN TEXT NOT NULL,
    lastN TEXT NOT NULL,
    grade INTEGER,
    advisor TEXT,
    email1 TEXT,
    email2 TEXT,
    veracross INTEGER NOT NULL,
    class INTEGER NOT NULL,
    FOREIGN KEY (class)
        REFERENCES userClass (level)
    );

REATE TABLE IF NOT EXISTS userClass (
    level INTEGER PRIMARY KEY NOT NULL UNIQUE,
    bedit INTEGER NOT NULL,
    comment INTEGER NOT NULL,
    cedit INTEGER NOT NULL
    );