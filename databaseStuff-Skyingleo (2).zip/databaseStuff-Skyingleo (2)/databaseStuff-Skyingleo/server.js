const express = require('express');
const mustache = require('mustache-express');
const app = express();
const server = require('http').createServer(app);
const io = require('socket.io')(server);
let allBooks = [];
let allUsers = [];
var sqlite3 = require('sqlite3');
//const mysql = require('mysql2');
let db = new sqlite3.Database('./file.db', sqlite3.OPEN_READWRITE, (err) => {
	if(err)
		console.log(err);

	console.log("conneted!");
});

app.use(express.static(__dirname + "/public"));
app.set('views', __dirname + "/views");
app.set('view engine', 'mustache');
app.engine('mustache', mustache());

db.run(`DROP TABLE IF EXISTS messageHistory;`);
db.run(`DROP TABLE IF EXISTS book;`);
db.run(`DROP TABLE IF EXISTS user;`);

db.run(`CREATE TABLE IF NOT EXISTS book (
	bID INTEGER PRIMARY KEY NOT NULL UNIQUE,
	title TEXT NOT NULL,
	author TEXT NOT NULL,
	callN TEXT NOT NULL,
	status INTEGER,
	location TEXT,
	sublocation TEXT,
	FOREIGN KEY (status)
		REFERENCES user (uID)
	);`);

db.run(`CREATE TABLE IF NOT EXISTS user (
	uID INTEGER PRIMARY KEY NOT NULL UNIQUE,
	firstN TEXT NOT NULL,
	middleN TEXT,
	lastN TEXT NOT NULL,
	veracross INTEGER NOT NULL,
	class INTEGER NOT NULL
	);`);


//db.run("CREATE TABLE messageHistory (message TEXT);");
//db.run("INSERT INTO messageHistory VALUES (?);", ["What's up guys"]);
//db.run("INSERT INTO messageHistory VALUES ('Not much');");
//db.run("DELETE FROM messageHistory;");
// dispatch query for first two rows in messageHistory table
db.all("SELECT message FROM messageHistory;", (err, answer) => {
	if (err || answer.length == 0) {
		console.log(err);
		return;
	}

	for(let i = 0; i < answer.length; i++){
		allMessages[i] = answer[i].message;
	}
	console.log(allMessages);
	//The messageHistory is the datat table, the rows are objects, and the colombs names are 
});

app.get("/", (req, res) => {
	res.render('home');
});

io.on("connection", (socket) =>{
	//when we receive "new message" 
});


io.on("connection", (socket) => {
	console.log("User: " + socket.id + " conneted"); 
// rh render the catch up list
	console.log(allMessages);
	io.to(socket.id).emit('texthistory', allMessages);

	socket.on('message', function (messageContents){
		console.log(messageContents);
		allMessages.push(messageContents);
		db.run("INSERT INTO messageHistory VALUES (?);", [messageContents]);
		console.log("I runned you bitch");
		//console.log(messageHistory);
		io.emit('textline', messageContents);
	});


});



server.listen(8080, () => {
	console.log("server go vroom");
});
