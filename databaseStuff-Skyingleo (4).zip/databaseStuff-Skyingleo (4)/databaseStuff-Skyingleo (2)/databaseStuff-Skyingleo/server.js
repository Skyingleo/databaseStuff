const express = require('express');
const mustache = require('mustache-express');
const app = express();
const server = require('http').createServer(app);
const io = require('socket.io')(server);

let nBook = 0;
let allbID = [];
let allbarC =[];
let allTitle = [];
let allAuthor = [];
let allCallN = [];
let allStatus = [];
let allLoaction = [];
let allsublocation = [];
let allGlimit = [];

let allBook = [];

// for (let a = 0; a < nBook; a++){
// 	allBook[a] = 
// 	"Book ID: " + allbID[a] + 
// 	"Title: " + allTitle[a] + 
// 	"Author: " + allAuthor[a] + 
// 	"Call Number: " + allCallN[a] + 
// 	"Status: " + allStatus[a] + 
// 	"Which Campus: " + allLoaction[a] + 
// 	"Location: " + allsublocation[a] + 
// 	"Grade Limit: " + allGlimit[a];
// }

let nUser = 0;
let alluID = [];
let allFirstN = [];
let allLastN = [];
let allGrade = [];
let allAdviser = [];
let allEmail1 = [];
let allEmail2 = [];
let allVeracross = [];
let allClass = [];

let allUser = [];

// for (let b = 0; b < nUser; b++){
// 	allUser[b] = 
// 	"User ID: " + alluID[b] + 
// 	"First Name: " + allFirstN[b] + 
// 	"Lat Names: " + allLastN[b] + 
// 	"Grade: " + allGrade[b] + 
// 	"Advisor: " + allAdviser[b] + 
// 	"Email 1: " + allEmail1[b] + 
// 	"Email 2: " + allEmail2[b] + 
// 	"Veracross Number: " + allVeracross[b] +
// 	"User's access level: " + allClass[b];
// }
const mysql = require("mysql2");
const connection = mysql.createConnection({
    host: "localhost",
    user: "my_user",
    password: "my_password123",
    database: "ldb"
});

var sqlite3 = require('sqlite3');
//const mysql = require('mysql2');
let db = new sqlite3.Database('./file.db', sqlite3.OPEN_READWRITE, (err) => {
	if(err)
		console.log(err);

	console.log("conneted!");
});

app.use(express.static(__dirname + "/public"));
app.set('views', __dirname + "/views");
app.set('view engine', 'mustache');
app.engine('mustache', mustache());

//db.run(`DROP TABLE IF EXISTS messageHistory;`);
//db.run(`DROP TABLE IF EXISTS book;`);
//db.run(`DROP TABLE IF EXISTS user;`);

// db.run(`CREATE TABLE IF NOT EXISTS book (
//     id INTEGER PRIMARY KEY NOT NULL UNIQUE,
//     title TEXT NOT NULL,
//     author TEXT NOT NULL,
//     callN TEXT NOT NULL,
//     status INTEGER,
//     location TEXT,
//     sublocation TEXT,
//     glimit INTEGER,
//     FOREIGN KEY (status)
//         REFERENCES user (id)
//     );`);

// db.run(`CREATE TABLE IF NOT EXISTS user (
//     id INTEGER PRIMARY KEY NOT NULL UNIQUE,
//     firstN TEXT NOT NULL,
//     lastN TEXT NOT NULL,
//     grade INTEGER,
//     advisor TEXT,
//     email1 TEXT,
//     email2 TEXT,
//     veracross INTEGER NOT NULL,
//     class INTEGER NOT NULL,
//     FOREIGN KEY (class)
//         REFERENCES userClass (level)
//     );`);

// db.run(`CREATE TABLE IF NOT EXISTS userClass (
// 	level INTEGER PRIMARY KEY NOT NULL UNIQUE,
// 	bedit INTEGER NOT NULL,
// 	comment INTEGER NOT NULL,
// 	cedit INTEGER NOT NULL
// 	);`);

//db.run("CREATE TABLE messageHistory (message TEXT);");
//db.run("INSERT INTO messageHistory VALUES (?);", ["What's up guys"]);
//db.run("INSERT INTO messageHistory VALUES ('Not much');");
//db.run("DELETE FROM messageHistory;");
// dispatch query for first two rows in messageHistory table

db.all("SELECT id FROM book;", (err, bIDs) => {
	if (err || bIDs.length == 0) {
		console.log(err);
		return;
	}

	nBook = bIDs.length;

	for(let i = 0; i < bIDs.length; i++){
		allbID[i] = bIDs[i].id;
	}
	console.log(allbID);
});

db.all("SELECT title FROM book;", (err, titles) => {
	if (err || titles.length == 0) {
		console.log(err);
		return;
	}

	for(let i = 0; i < titles.length; i++){
		allTitle[i] = titles[i].title;
	}
	console.log(allTitle);
});

db.all("SELECT author FROM book;", (err, authors) => {
	if (err || authors.length == 0) {
		console.log(err);
		return;
	}

	for(let i = 0; i < authors.length; i++){
		allAuthor[i] = authors[i].author;
	}
	//console.log(allTitle);
});

db.all("SELECT callN FROM book;", (err, callNs) => {
	if (err || callNs.length == 0) {
		console.log(err);
		return;
	}

	for(let i = 0; i < callNs.length; i++){
		allCallN[i] = callNs[i].callN;
	}
	//console.log(allTitle);
});

db.all("SELECT status FROM book;", (err, statuss) => {
	if (err || statuss.length == 0) {
		console.log(err);
		return;
	}

	for(let i = 0; i < statuss.length; i++){
		if (statuss[i].status == null){
			allStatus[i] = 'available';
		}
		else{
			allStatus[i] = statuss[i].status;
		}
	}
	//console.log(allTitle);
});

db.all("SELECT location FROM book;", (err, locations) => {
	if (err || locations.length == 0) {
		console.log(err);
		return;
	}

	for(let i = 0; i < locations.length; i++){
		if (locations[i].location == null){
			allLoaction[i] = "unknown";
		}
		else{
			allLoaction[i] = locations[i].location;
		}
		
	}
	//console.log(allTitle);
});

db.all("SELECT sublocation FROM book;", (err, sublocations) => {
	if (err || sublocations.length == 0) {
		console.log(err);
		return;
	}

	for(let i = 0; i < sublocations.length; i++){
		if (sublocations[i].sublocation == null){
			allsubLoaction[i] = "unknown";
		}
		else{
			allsublocation[i] = sublocations[i].sublocation;
		}
	}
	//console.log(allTitle);
});

db.all("SELECT glimit FROM book;", (err, glimits) => {
	if (err || glimits.length == 0) {
		console.log(err);
		return;
	}

	for(let i = 0; i < glimits.length; i++){
		if (glimits[i].glimit == null){
			allGlimit[i] = "none";
		}
		else{
			allGlimit[i] = glimits[i].glimit;
		}
	}
	//console.log(allTitle);
});


db.all("SELECT id FROM user;", (err, uIDs) => {
	if (err || uIDs.length == 0) {
		console.log(err);
		return;
	}

	nUser = uIDs.length;

	for(let i = 0; i < uIDs.length; i++){
		alluID[i] = uIDs[i].id;
	}
	console.log(alluID);
});

db.all("SELECT firstN FROM user;", (err, firstNs) => {
	if (err || firstNs.length == 0) {
		console.log(err);
		return;
	}

	for(let i = 0; i < firstNs.length; i++){
		allFirstN[i] = firstNs[i].firstN;
	}
});

db.all("SELECT lastN FROM user;", (err, lastNs) => {
	if (err || lastNs.length == 0) {
		console.log(err);
		return;
	}

	for(let i = 0; i < lastNs.length; i++){
		allLastN[i] = lastNs[i].lastN;
	}
});

db.all("SELECT grade FROM user;", (err, grades) => {
	if (err || grades.length == 0) {
		console.log(err);
		return;
	}

	for(let i = 0; i < grades.length; i++){
		if (grades[i].grade == null){
			allGrade[i] = "unknown";
		}
		else{
			allGrade[i] = grades[i].grade;
		}
	}
});

db.all("SELECT advisor FROM user;", (err, advisors) => {
	if (err || advisors.length == 0) {
		console.log(err);
		return;
	}

	for(let i = 0; i < advisors.length; i++){
		if (advisors[i].advisor == null){
			allAdviser[i] = "unknown";
		}
		else{
			allAdviser[i] = advisors[i].advisor;
		}
	}
});

db.all("SELECT email1 FROM user;", (err, email1s) => {
	if (err || email1s.length == 0) {
		console.log(err);
		return;
	}

	for(let i = 0; i < email1s.length; i++){
		if (email1s[i].email1 == null){
			allEmail1[i] = "unknown";
		}
		else{
			allEmail1[i] = email1s[i].email1;
		}
	}
});

db.all("SELECT email2 FROM user;", (err, email2s) => {
	if (err || email2s.length == 0) {
		console.log(err);
		return;
	}

	for(let i = 0; i < email2s.length; i++){
		if (email2s[i].email2 == null){
			allEmail2[i] = "unknown";
		}
		else{
			allEmail2[i] = email2s[i].email2;
		}
	}
});

db.all("SELECT veracross FROM user;", (err, veracrosss) => {
	if (err || veracrosss.length == 0) {
		console.log(err);
		return;
	}

	for(let i = 0; i < veracrosss.length; i++){
		allVeracross[i] = veracrosss[i].veracross;
	}
});

db.all("SELECT class FROM user;", (err, classs) => {
	if (err || classs.length == 0) {
		console.log(err);
		return;
	}

	for(let i = 0; i < classs.length; i++){
		allClass[i] = classs[i].class;
	}
});

app.get("/", (req, res) => {
	res.render('home');
});

io.on("connection", (socket) =>{
	//when we receive "new message" 
});


io.on("connection", (socket) => {
	console.log("User: " + socket.id + " conneted"); 
// rh render the catch up list
	console.log(allMessages);
	io.to(socket.id).emit('bRecord', allBook);
	io.to(socket.id).emit('uRecord', allUser);
	socket.on('message', function (messageContents){
		console.log(messageContents);
		allMessages.push(messageContents);
		db.run("INSERT INTO messageHistory VALUES (?);", [messageContents]);
		console.log("I runned you bitch");
		//console.log(messageHistory);
		io.emit('textline', messageContents);
	});

	socket.on('bID', function (bIDc){
		console.log(bIDc);
		allbID.push(bIDc);
		db.run("INSERT INTO book(id) VALUES (?);", [bIDc]);
		io.emit('bIDr', bIDc);
	});

	socket.on('barCode', function (barCodec){
		allbID.push(bIDc);
		db.run("INSERT INTO book(id) VALUES (?);", [bIDc]);
		io.emit('bIDr', bIDc);
	});

	socket.on('title', function (titlec){
		allTitle.push(titlec);
		db.run("INSERT INTO book(title) VALUES (?);", [titlec]);
		//io.emit('textline', messageContents);
	});

	socket.on('author', function (authorc){
		allAuthor.push(authorc);
		db.run("INSERT INTO book(author) VALUES (?);", [authorc]);
		//io.emit('textline', messageContents);
	});

	socket.on('callN', function (callNc){
		allCallN.push(callNc);
		db.run("INSERT INTO book(callN) VALUES (?);", [callNc]);
		//io.emit('textline', messageContents);
	});

	socket.on('status', function (statusc){
		if (statusc == null){
			allStatus.push("available");
		}
		else{
			all.push(statusc);
		}	
		db.run("INSERT INTO book(status) VALUES (?);", [statusc]);
		//io.emit('textline', messageContents);
	});

	socket.on('location', function (locationc){
		if (locationc == null){
			allLoaction.push("unknown");
		}
		else{
			allLoaction.push(locationc);
		}
		db.run("INSERT INTO book(location) VALUES (?);", [locationc]);
		//io.emit('textline', messageContents);
	});

	socket.on('sublocation', function (sublocationc){
		if (sublocationc == null){
			allsubLoaction.push("unknown");
		}
		else{
			allsublocation.push(sublocationc);
		}
		db.run("INSERT INTO book(sublocation) VALUES (?);", [sublocationc]);
		//io.emit('textline', messageContents);
	});

	socket.on('glimit', function (glimitc){
		if (glimitc == null){
			allGlimit.push("none");
		}
		else{
			allGlimit.push(glimitc);
		}
		db.run("INSERT INTO book(glimit) VALUES (?);", [glimitc]);
		//io.emit('textline', messageContents);
	});



	
	socket.on('uID', function (uIDc){
		alluID.push(uIDc);
		db.run("INSERT INTO user(id) VALUES (?);", [uIDc]);
		//io.emit('textline', messageContents);
	});

	socket.on('firstN', function (firstNc){
		allFirstN.push(firstNc);
		db.run("INSERT INTO user(firstN) VALUES (?);", [firstNc]);
		//io.emit('textline', messageContents);
	});

	socket.on('lastN', function (lastNc){
		allLastN.push(lastNc);
		db.run("INSERT INTO user(lastN) VALUES (?);", [lastNc]);
		//io.emit('textline', messageContents);
	});

	socket.on('grade', function (gradec){
		if (gradec == null){
			allGrade.push("unknown");
		}
		else{
			allGrade.push(c);
		}
		db.run("INSERT INTO user(grade) VALUES (?);", [gradec]);
		//io.emit('textline', messageContents);
	});

	socket.on('advisor', function (advisorc){
		if (advisorc == null){
			allAdviser.push("unknown");
		}
		else{
			allAdviser.push(c);
		}
		db.run("INSERT INTO user(advisor) VALUES (?);", [advisorc]);
		//io.emit('textline', messageContents);
	});

	socket.on('email1', function (email1c){
		if (email1c == null){
			allEmail1.push("unknown");
		}
		else{
			allEmail1.push(email1c);
		}
		db.run("INSERT INTO user(email1) VALUES (?);", [email1c]);
		//io.emit('textline', messageContents);
	});

	socket.on('email2', function (email2c){
		if (email2c == null){
			allEmail2.push("unknown");
		}
		else{
			allEmail2.push(email2c);
		}
		db.run("INSERT INTO user(email2) VALUES (?);", [email2c]);
		//io.emit('textline', messageContents);
	});

	socket.on('veracross', function (veracrossc){
		all.push(veracrossc);
		db.run("INSERT INTO user(veracross) VALUES (?);", [veracrossc]);
		//io.emit('textline', messageContents);
	});


	socket.on('class', function (classc){
		all.push(classc);
		db.run("INSERT INTO user(class) VALUES (?);", [classc]);
		//io.emit('textline', messageContents);
	});

	// socket.on('', function (c){
	// 	all.push(c);
	// 	db.run("INSERT INTO user() VALUES (?);", [c]);
	// 	//io.emit('textline', messageContents);
	// });

	// socket.on('', function (c){
	// 	all.push(c);
	// 	db.run("INSERT INTO user() VALUES (?);", [c]);
	// 	//io.emit('textline', messageContents);
	// });

	// socket.on('', function (c){
	// 	all.push(c);
	// 	db.run("INSERT INTO user() VALUES (?);", [c]);
	// 	//io.emit('textline', messageContents);
	// });

	// socket.on('', function (c){
	// 	all.push(c);
	// 	db.run("INSERT INTO user() VALUES (?);", [c]);
	// 	//io.emit('textline', messageContents);
	// });

});


server.listen(8080, () => {
	console.log("server go vroom");
});
