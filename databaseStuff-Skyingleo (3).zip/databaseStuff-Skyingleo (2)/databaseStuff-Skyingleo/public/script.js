//setInterval(run, 2000);
const socket = io();
const Title = document.getElementById("Title");
const Author = document.getElementById("Author");
const cTree = document.getElementsByClassName("body-bg");

socket.on("connect", () => {
  console.log(socket.id); // x8WIv7-mJelg7on_ALbx
});

$ ("#bEnter").click(function(){
	//console.log("Title: " + $('#title').val() + "Author: " + $('#author').val());
	socket.emit('bID', $('#bID').val());
	socket.emit('title', $('#title').val());
	socket.emit('author', $('#author').val());
	socket.emit('callN',$('#callN').val());
	socket.emit('status',$('#status').val());
	socket.emit('location',$('#location').val());
	socket.emit('subloaction',$('#subloaction').val());
})

$ ("#uEnter").click(function(){
	//console.log('message', "Title: " + $('#title').val() + "Author: " + $('#author').val());
	socket.emit('uID', $('#uID').val());
	socket.emit('firstN', $('#firstN').val());
	socket.emit('middleN', $('#middleN').val());
	socket.emit('lastN',$('#lastN').val());
	socket.emit('veracross',$('#veracross').val());
	socket.emit('class',$('#class').val());
})


socket.on('count', function (data) {
  $('.user-count').html(data);
});

// When we receive a message``
// it will be like { user: 'username', message: 'text' }
socket.on('textline', function (data) {
	console.log(data);
  	$('ul').append("<li>"+data+'</li>');
});

socket.on('texthistory', function (data) {
	console.log(data);
	for (let i = 0; i < data.length; i++){
	  	$('ul').append("<li>"+data[i]+'</li>');
	}
});
//<script.src = "/socket.io/socket.io.js"></script>